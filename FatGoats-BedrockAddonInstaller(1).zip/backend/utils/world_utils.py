import os

def list_worlds():
    return {"worlds": ["World1", "World2"]}
