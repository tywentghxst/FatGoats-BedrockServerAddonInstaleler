# Contributing

Thanks for considering a contribution to FatGoats BedrockAddonInstaller!

## How to Contribute
1. Fork the repo
2. Create a feature branch
3. Submit a pull request

All PRs are welcome as long as they help people goat around better. 🐐
